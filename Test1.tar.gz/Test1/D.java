 
public class D extends B { 

   Object d;
   
   D(Object a, Object b){
     super(a, b);
     d = new Object();
   }
   
   D(Object a, Object b, Object c){
      super(a, b);
      this.d = c;
   }
   

   
   
 

   
   
   
}